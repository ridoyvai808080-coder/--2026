GitHub Pages setup:
1. Upload index.html and EMON-Panel-Sance-2.0.apk to the same GitHub repository folder.
2. Enable GitHub Pages from Settings > Pages.
3. The Download APK button points to the original APK filename.
Password: emonsance
